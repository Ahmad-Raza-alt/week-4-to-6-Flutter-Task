import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class UserProfileScreen extends StatelessWidget {
  Future<Map<String, dynamic>> fetchUser() async {
    final res = await http.get(Uri.parse('https://reqres.in/api/users/2'));
    return json.decode(res.body)['data'];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Single User")),
      body: FutureBuilder(
        future: fetchUser(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return Center(child: CircularProgressIndicator());
          final user = snapshot.data as Map<String, dynamic>;
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CircleAvatar(radius: 50, backgroundImage: NetworkImage(user['avatar'])),
                SizedBox(height: 16),
                Text("${user['first_name']} ${user['last_name']}", style: TextStyle(fontSize: 20)),
                Text(user['email']),
              ],
            ),
          );
        },
      ),
    );
  }
}
