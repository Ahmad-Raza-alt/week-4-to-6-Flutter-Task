import 'package:flutter/material.dart';

class ProfileScreen extends StatelessWidget {
  final String name = "Ahmad Raza";
  final String email = "ahmadtask@gmail.com";
  final String about =
      "I’m a Computer Science graduate with skills in Flutter, HTML, CSS, and building full-stack projects like BiteBox. Passionate about mobile app development!";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("My Profile")),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            CircleAvatar(
              radius: 60,
              backgroundImage: AssetImage('assets\1 (4).jpg'),
              backgroundColor: Colors.grey[300],
            ),
            SizedBox(height: 16),
            Text(name,
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            Text(email,
                style: TextStyle(fontSize: 16, color: Colors.grey[600])),
            Divider(height: 32),
            Align(
              alignment: Alignment.centerLeft,
              child: Text(
                "About Me",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
              ),
            ),
            SizedBox(height: 8),
            Text(
              about,
              style: TextStyle(fontSize: 15, color: Colors.black87),
              textAlign: TextAlign.justify,
            ),
          ],
        ),
      ),
    );
  }
}
