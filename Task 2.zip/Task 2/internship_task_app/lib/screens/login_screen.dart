import 'package:flutter/material.dart';
import 'dashboard_screen.dart';

class LoginScreen extends StatelessWidget {
  final TextEditingController emailCtrl = TextEditingController();
  final TextEditingController passwordCtrl = TextEditingController();

  void login(BuildContext context) {
    final email = emailCtrl.text.trim();
    final password = passwordCtrl.text.trim();

    if (email == 'ahmadtask@gmail.com' && password == '123456') {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => DashboardScreen()),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Invalid credentials")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Login")),
      body: Center(
        child: SingleChildScrollView(
          padding: EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.lock, size: 80, color: Colors.grey[700]),
              SizedBox(height: 24),
              Text("Welcome to my 4 to 6 Week Task",
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              SizedBox(height: 24),
              TextField(
                  controller: emailCtrl,
                  decoration: InputDecoration(labelText: "Email")),
              SizedBox(height: 16),
              TextField(
                  controller: passwordCtrl,
                  obscureText: true,
                  decoration: InputDecoration(labelText: "Password")),
              SizedBox(height: 24),
              ElevatedButton(
                onPressed: () => login(context),
                style: ElevatedButton.styleFrom(
                    minimumSize: Size(double.infinity, 48)),
                child: Text("Login"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
