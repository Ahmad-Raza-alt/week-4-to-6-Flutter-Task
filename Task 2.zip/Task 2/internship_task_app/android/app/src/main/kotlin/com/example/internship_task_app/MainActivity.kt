package com.example.internship_task_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
